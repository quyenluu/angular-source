export interface CartModel {
    id: any;
    img: string;
    product: string;
    quantity: any;
    price: any;
  }
  