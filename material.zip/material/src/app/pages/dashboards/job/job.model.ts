export interface JobModel {
  id: string;
  c_name: string;
  position: string;
  location: string;
  salary: string;
  experience: string;
  job_type: string;
}

export interface candidateModel {
  id: string;
  image: string;
  name: string;
  insta: string;
  designation: string;
}
