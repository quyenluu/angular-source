// Api Key
const apikeys = [
    {
        id: 1,
        name: 'Streamlab',
        createdby: 'Tara Hawkins',
        key: '9e6d336a-2f98-43e9-9fa6-11b4d5cdaf62',
        status: 'Disable',
        color: 'danger',
        create_date: '24 Sep 2022',
        expiry_date: '24 Jan 2023'
    },
    {
        id: 2,
        name: 'Streamlab',
        createdby: 'Nicki Butler',
        key: '8abba6e5-9622-46d2-8c52-c937e1d20ba2',
        status: 'Active',
        color: 'success',
        create_date: '24 Sep 2022',
        expiry_date: '24 Jan 2023'
    },
    {
        id: 3,
        name: 'Streamlab',
        createdby: 'Addison Black',
        key: 'aecc1ede-f613-48d5-8140-7108b324f0bd',
        status: 'Active',
        color: 'success',
        create_date: '24 Sep 2022',
        expiry_date: '24 Jan 2023'
    },
    {
        id: 4,
        name: 'Streamlab',
        createdby: 'Harley Watkins',
        key: '84540348-f97d-41de-87c6-f5eae32aecc5',
        status: 'Disable',
        color: 'danger',
        create_date: '24 Sep 2022',
        expiry_date: '24 Jan 2023'
    },
    {
        id: 5,
        name: 'Streamlab',
        createdby: 'Cassian Jenning',
        key: '33ec3a35-8b44-48f3-ba68-f3ea1e9ef214',
        status: 'Active',
        color: 'success',
        create_date: '24 Sep 2022',
        expiry_date: '24 Jan 2023'
    },
    {
        id: 6,
        name: 'Streamlab',
        createdby: 'Elizabeth Allen',
        key: 'b69ee258-1053-4e08-adbd-d37837f9c558',
        status: 'Active',
        color: 'success',
        create_date: '24 Sep 2022',
        expiry_date: '24 Jan 2023'
    },
    {
        id: 7,
        name: 'Streamlab',
        createdby: 'Philippa Santiago',
        key: '0b53e8e2-e53d-4067-8be0-9cddea19e45e',
        status: 'Active',
        color: 'success',
        create_date: '24 Sep 2022',
        expiry_date: '24 Jan 2023'
    },
    {
        id: 8,
        name: 'Streamlab',
        createdby: 'Zynthia Marrow',
        key: 'ed4c0d11-7d49-4c94-aae8-83fafb226ee9',
        status: 'Active',
        color: 'success',
        create_date: '24 Sep 2022',
        expiry_date: '24 Jan 2023'
    },
    {
        id: 9,
        name: 'Streamlab',
        createdby: 'Michael Morris',
        key: 'fef67078-6fb6-4689-b342-6ddc24481728',
        status: 'Disable',
        color: 'danger',
        create_date: '24 Sep 2022',
        expiry_date: '24 Jan 2023'
    }
]

export { apikeys }