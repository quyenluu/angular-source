import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alt',
  templateUrl: './alt.component.html',
  styleUrls: ['./alt.component.scss']
})

/**
 * 404 Alt Component
 */
export class AltComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
